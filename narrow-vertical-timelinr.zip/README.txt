A Pen created at CodePen.io. You can find this one at http://codepen.io/tylerberry/pen/LEzrXm.

 Making a narrow version of the Timelinr plugin to fit on a mobile screen.